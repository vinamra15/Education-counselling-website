var scl;
var layout;
var data;
$(document).ready(function(){
	$.ajax({
		url: "data.php", 
		method: "GET",
		success: function(data) {
			console.log(data);
			var Well_Name = [];
			var Field = [];
			var Spud_Date = [];
			var Target_Depth = [];
			var Driller_Depth = [];
			var Longitude = [];
			var Latitude = [];


			for(var i in data) {
				Well_Name.push("Well_Name : " + data[i].Well_Name);
				Field.push(data[i].Field);
				Spud_Date.push(data[i].Spud_Date);
				Target_Depth.push(data[i].Target_Depth);
				Driller_Depth.push("Driller_Depth: " + data[i].Driller_Depth);
				Longitude.push(data[i].Longitude);
				Latitude.push(data[i].Latitude);
				
}
		
	
scl = [[1000,'rgb(5, 10, 172)'],[1800,'rgb(40, 60, 190)'],[2600,'rgb(70, 100, 245)'], [3500,'rgb(90, 120, 245)'],[4000,'rgb(106, 137, 247)'],[5000,'rgb(220, 220, 220)']];  
  
	data = [{
    type:'scattergeo',
    locationmode: 'asia',
    lon: Longitude,
    lat: Latitude,
    text: Driller_Depth,
    mode: 'markers',
    marker: {
      size: 8,
      opacity: 0.8,
      reversescale: true,
      autocolorscale: false,
      symbol: 'circle',
      line: {
        width: 1,
        color: 'rgb(102,102,102)'
      },
      colorscale: scl,
      cmin: 0,
      color: Target_Depth,
      colorbar: {
         title: 'SCALE'
      }
    }
}];


layout = {
      title: 'Most Density OIL FIELDS',
      autocolorscale: false,
      geo: {
        scope: 'asia',
		resolution: 50,
        projection: {
          //type: 'albers usa'
        },lonaxis: {
                'range': [68.97]
            },
            lataxis: {
                'range': [8,37]
            },
        showland: true,
        landcolor: '#FFCC99',
		showrivers: true,
        subunitcolor: 'black',
        countrycolor: 'green',
        countrywidth: 0.5,
        subunitwidth: 0.5
      }
    };
  
Plotly.plot(myDiv, data, layout, {showLink: false});
  }
});
});