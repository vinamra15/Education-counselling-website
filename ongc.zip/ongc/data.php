<?php
header('Content-Type: application/json');
$con=mysqli_connect('localhost','root','','score');
if (mysqli_connect_errno()) {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
}
$query = sprintf("SELECT * FROM ongc");
$result = $con->query($query);
$data = array();
foreach ($result as $row) {
	$data[] = $row;}
$result->close();
$con->close();
print json_encode($data);
?>